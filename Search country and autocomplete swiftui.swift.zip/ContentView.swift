import SwiftUI

struct Country {
    var name: String
}

struct ContentView: View {
    let countries = [
        Country(name: "United States"),
        Country(name: "Canada"),
        Country(name: "Mexico"),
        Country(name: "Brazil"),
        Country(name: "Australia"),
        Country(name: "China"),
        Country(name: "France"),
        Country(name: "Germany"),
        Country(name: "India"),
        Country(name: "Japan"),
        Country(name: "South Korea"),
        Country(name: "Netherlands"),
        Country(name: "New Zealand"),
        Country(name: "Russia"),
        Country(name: "Spain"),
        Country(name: "Sweden"),
        Country(name: "Switzerland"),
        Country(name: "United Kingdom"),
        Country(name: "Cambodia")
    ]
    @State private var searchText = ""
    @State private var isSearching = false
    
    var filteredCountries: [Country] {
        if searchText.isEmpty {
            return countries
        } else {
            return countries.filter { $0.name.lowercased().contains(searchText.lowercased()) }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                TextField("Search country", text: $searchText)
                    .padding(.horizontal, 25)
                    .padding(.vertical, 10)
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                    .padding(.horizontal, 10)
                    .onTapGesture {
                        self.isSearching = true
                    }
                
                List {
                    ForEach(filteredCountries, id: \.name) { country in
                        Text(country.name)
                            .onTapGesture {
                                self.searchText = country.name
                                self.isSearching = false
                            }
                    }
                }
                .navigationBarTitle(Text("Countries"))
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
