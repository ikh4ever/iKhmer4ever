import SwiftUI

struct Country {
    var name: String
}

struct ContentView: View {
    let countries = [
        Country(name: "United States"),
        Country(name: "Canada"),
        Country(name: "Mexico"),
        Country(name: "Brazil"),
        Country(name: "Australia"),
        Country(name: "China"),
        Country(name: "France"),
        Country(name: "Germany"),
        Country(name: "India"),
        Country(name: "Japan"),
        Country(name: "South Korea"),
        Country(name: "Netherlands"),
        Country(name: "New Zealand"),
        Country(name: "Russia"),
        Country(name: "Spain"),
        Country(name: "Sweden"),
        Country(name: "Switzerland"),
        Country(name: "United Kingdom"),
        Country(name: "Arab")
    ]
    @State private var selectedCountryIndex = 0
    
    var body: some View {
        VStack {
            Picker(selection: $selectedCountryIndex, label: Text("Select a Country")) {
                ForEach(0 ..< countries.count) {
                    Text(self.countries[$0].name)
                }
            }
            Text("You selected \(countries[selectedCountryIndex].name)")
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
