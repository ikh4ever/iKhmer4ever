import SwiftUI
import Foundation

struct ImageData: Identifiable {
    let id: Int
    let imageName: String
}

struct ContentView: View {
    @State var images = [
        ImageData(id: 1, imageName: "Cat1"),
        ImageData(id: 2, imageName: "Cat2"),
        ImageData(id: 3, imageName: "Cat3"),
        ImageData(id: 4, imageName: "Cat4"),
        ImageData(id: 5, imageName: "Cat5"),
        ImageData(id: 6, imageName: "Cat6"),
        
    ]
        
        @State private var draggingImage: ImageData?
        @State private var dragOffset: CGSize = .zero
        
        var body: some View {
            VStack {
                Text("iKh4ever Demo \nDrag an image to move it.")
                
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())]) {
                    ForEach(images) { image in
                        Image(image.imageName)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding(10)
                            .background(draggingImage?.id == image.id ? Color.gray : Color.clear)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                            .offset(draggingImage?.id == image.id ? dragOffset : .zero)
                            .gesture(
                                DragGesture()
                                    .onChanged { value in
                                        self.draggingImage = image
                                        self.dragOffset = value.translation
                                    }
                                    .onEnded { value in
                                        withAnimation {
                                            let currentIndex = images.firstIndex(where: { $0.id == draggingImage?.id })
                                            let newIndex = max(min((currentIndex ?? 0) + Int((value.translation.width / 100)), images.count - 1), 0)
                                            if newIndex != currentIndex {
                                                images.move(fromOffsets: IndexSet(integer: currentIndex!), toOffset: newIndex)
                                            }
                                            self.draggingImage = nil
                                            self.dragOffset = .zero
                                        }
                                    }
                            )
                    }
                }
            }
        }
    }
