import SwiftUI

struct MatrixMultiplicationView: View {
    @State private var rowsA = 2
    @State private var columnsA = 2
    @State private var rowsB = 2
    @State private var columnsB = 2
    @State private var rowsC = 2
    @State private var columnsC = 2
    @State private var matrixA: [[Int]] = Array(repeating: Array(repeating: 0, count: 2), count: 2)
    @State private var matrixB: [[Int]] = Array(repeating: Array(repeating: 0, count: 2), count: 2)
    @State private var matrixC: [[Int]] = Array(repeating: Array(repeating: 0, count: 2), count: 2)
    
    var body: some View {
        VStack {
            Text("Matrix Multipulation")
                .font(.title)
            Text("Matrix A")
            MatrixInputView(rows: $rowsA, columns: $columnsA, matrix: $matrixA)
            Text("Matrix B")
            MatrixInputView(rows: $rowsB, columns: $columnsB, matrix: $matrixB)
            Text("Matrix C")
            MatrixInputView(rows: $rowsC, columns: $columnsC, matrix: $matrixC)
            Button("Multiply") {
                let resultAB = multiply(matrixA: matrixA, matrixB: matrixB)
                matrixC = resultAB
                print(resultAB)
            }
        }.padding(EdgeInsets.init(top: 30, leading: 30, bottom: 15, trailing: 30))
    }

    
    func multiply(matrixA: [[Int]], matrixB: [[Int]]) -> [[Int]] {
        var result = Array(repeating: Array(repeating: 0, count: matrixB[0].count), count: matrixA.count)
        for i in 0..<matrixA.count {
            for j in 0..<matrixB[0].count {
                for k in 0..<matrixB.count {
                    result[i][j] += matrixA[i][k] * matrixB[k][j]
                }
            }
        }
        return result
    }
}

struct MatrixInputView: View {
    @Binding var rows: Int
    @Binding var columns: Int
    @Binding var matrix: [[Int]]
    
    var body: some View {
        VStack {
            HStack {
                Text("Rows")
                Stepper(value: $rows, in: 1...10) {
                    Text("\(rows)")
                }
            }
            HStack {
                Text("Columns")
                Stepper(value: $columns, in: 1...10) {
                    Text("\(columns)")
                }
            }
            VStack {
                ForEach(0..<rows, id: \.self) { row in
                    HStack(spacing: 16) {
                        ForEach(0..<columns, id: \.self) { column in
                            TextField("", value: $matrix[row][column], formatter: NumberFormatter())
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .keyboardType(.numberPad)
                                .frame(width: 50)
                        }
                    }
                }
            }
        }
    }
}
